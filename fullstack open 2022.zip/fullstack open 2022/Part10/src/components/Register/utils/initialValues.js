const initialValues = {
  username: '',
  password: '',
  passwordConfirmation: '',
};
export default initialValues;
