import RepositoryOList from './RepositoryOList';

export default RepositoryOList;
