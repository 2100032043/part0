import { StyleSheet } from 'react-native';

const filtersOStyles = StyleSheet.create({
  container: {
    padding: 10,
  },
});

export default filtersOStyles;
