import { StyleSheet } from 'react-native';

const rowViewStyles = StyleSheet.create({
  rowContainer: {
    flexDirection: 'row',
  },
});

export default rowViewStyles;
