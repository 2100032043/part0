import { StyleSheet } from 'react-native';

const itemOSeparatorStyles = StyleSheet.create({
  separator: {
    height: 6,
  },
});
export default itemOSeparatorStyles;
