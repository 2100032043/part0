import ItemOSeparator from './SeparatingItem';

export default ItemOSeparator;
