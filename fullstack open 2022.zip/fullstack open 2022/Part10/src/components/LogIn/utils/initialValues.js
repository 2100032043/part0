const initialOValues = {
  username: '',
  password: '',
};

export default initialOValues;
