import ReviewItem from './ReviewItem';

export default ReviewItem;
