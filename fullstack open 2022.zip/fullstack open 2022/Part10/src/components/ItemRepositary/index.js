import RepositoryOItem from './RepositoryOItem';

export default RepositoryOItem;
