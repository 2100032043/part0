import { StyleSheet } from 'react-native';
const StyleOLoaders = StyleSheet.create({
  loader: {
    padding: 5,
  },
});
export default StyleOLoaders;
