import LoOader from './LoadMaker';
export default LoOader;
