import MyOReviews from './MyReview';

export default MyOReviews;
