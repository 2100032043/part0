import React from 'react';
const StorageContextAuth = React.createContext();
export default StorageContextAuth;
