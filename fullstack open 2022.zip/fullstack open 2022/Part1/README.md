# Fullstackopen part 1 exercises

In this part, we will familiarize ourselves with the React-library, which we will be using to write the code that runs in the browser. We will also look at some features of Javascript that are important for understanding React.
