# Fullstackopen part 8 exercises

In this part of the course , we are going to learn about GraphQL, Facebook's alternative to REST for communication between browser and a server.
