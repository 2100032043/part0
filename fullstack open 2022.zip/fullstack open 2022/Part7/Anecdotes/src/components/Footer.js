import React from 'react'

const Footer = () => (
  <div>
    Anecdote app for{' '}

  </div>
)

export default Footer
