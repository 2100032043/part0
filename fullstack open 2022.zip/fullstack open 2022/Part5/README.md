# Fullstackopen part 5 exercises

We return to the begining, first looking at different possibilities for testing the React code. We will also implement token based authentication which will enable users to log in to our application.