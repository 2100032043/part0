# Bloglist-5

We will now create a frontend for the bloglist backend we created in the last part.
A login functionnality is also implemented for restricting the possibility to view and create blogs only by authenticated users. We assume that a user already exists with the good credentials.

Since the objective of this part is to test the react app, unit tests and end-to-end (E2E) tests with cypress are also implemented.