# Course contents

Simple web app for getting used to collections & modules.
